#include "statistics.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h> 

void Statistics_Calculing(double* jitterRef, double* jitterModeloRef, double* jitterControle, double* jitterLinear, double* jitterRobo, double fullTime)
{
    double somaRef=0,somaModeloRef=0, somaControle=0, somaLinear=0, somaRobo=0;
    double maximoRef,maximoModeloRef, maximoControle, maximoLinear, maximoRobo;
    double minimoRef,minimoModeloRef, minimoControle, minimoLinear, minimoRobo;
    double mediaRef,mediaModeloRef, mediaControle, mediaLinear, mediaRobo;
    double varianciaRef,varianciaModeloRef, varianciaControle, varianciaLinear, varianciaRobo;
    double desvioRef, desvioModeloRef, desvioControle, desvioLinear, desvioRobo;

    for(int i=0;i<fullTime;i++){
        somaRef=somaRef+jitterRef[i];
        somaModeloRef=somaModeloRef+jitterModeloRef[i];
        somaLinear=somaLinear+jitterLinear[i];
        somaControle=somaControle+jitterControle[i];
        somaRobo=somaRobo+jitterRobo[i];
    }

    mediaRef=somaRef/fullTime;
    mediaModeloRef=somaModeloRef/fullTime;
    mediaControle=somaControle/fullTime;
    mediaRobo=somaRobo/fullTime;
    mediaLinear=somaLinear/fullTime;

    printf("\n");
    for(int i=0;i<TIME_SIMULATION;i++){
        variancia1 += ((periodo_tarefa_1[i]-media1)*(periodo_tarefa_1[i]-media1));
        variancia2 += ((periodo_tarefa_2[i]-media2)*(periodo_tarefa_2[i]-media2));

        // printf("%.10lf ",periodo_tarefa_1[i]);
    }
    variancia1/(TIME_SIMULATION-1);
    variancia2/(TIME_SIMULATION-1);

    desvio_padrao1=sqrt(variancia1);
    desvio_padrao2=sqrt(variancia2);

    maximo1=0;
    maximo2=0;
    minimo1=999999999;
    minimo2=999999999;

    printf("\n");
    for(int i=0;i<TIME_SIMULATION;i++){
        if(periodo_tarefa_1[i]>maximo1){
            maximo1=periodo_tarefa_1[i];
        }
        if(periodo_tarefa_2[i]>maximo2){
            maximo2=periodo_tarefa_2[i];
        }
        if(periodo_tarefa_1[i]<minimo1){
            minimo1=periodo_tarefa_1[i];
        }
        if(periodo_tarefa_2[i]<minimo2){
            minimo2=periodo_tarefa_2[i];
        }
        // printf("%.10lf ",periodo_tarefa_2[i]);
    }
    printf("\n");
    printf("media1: %.10lf\n", media1);
    printf("media2: %.10lf\n", media2);
    printf("variancia1: %.10lf\n", variancia1);
    printf("variancia2: %.10lf\n", variancia2);
    printf("desvio_padrao1: %.10lf\n", desvio_padrao1);
    printf("desvio_padrao2: %.10lf\n", desvio_padrao2);
    printf("maximo1: %.10lf\n", maximo1);
    printf("maximo2: %.10lf\n", maximo2);
    printf("minimo1: %.10lf\n", minimo1);
    printf("minimo2: %.10lf\n", minimo2);


}