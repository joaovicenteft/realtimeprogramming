#ifndef YF_H
#define YF_H
#include "stdint.h"
#include "string.h"
#include "math.h"
#include "stdlib.h"
#include "matrix.h"

void calculingXt(matrix *ut,int t,double*vetor);


#endif